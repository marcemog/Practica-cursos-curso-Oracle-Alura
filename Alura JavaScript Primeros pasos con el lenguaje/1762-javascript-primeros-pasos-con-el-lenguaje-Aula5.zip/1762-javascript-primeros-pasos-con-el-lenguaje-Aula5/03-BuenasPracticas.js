let nombreEmpleado = "José Perez";
let NombreEmpleado = "Pedro Ramírez";

let edadEmpleado = 40;
console.log(edadEmpleado);
edadEmpleado = "Cuarenta";
console.log(edadEmpleado);
