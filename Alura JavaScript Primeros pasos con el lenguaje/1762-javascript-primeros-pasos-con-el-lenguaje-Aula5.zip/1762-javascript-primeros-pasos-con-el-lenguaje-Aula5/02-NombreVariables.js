const nombreEmpleado = "José Perez";
let direccion = "Av.105 - Calle 3";
var costoDelPasaje = 1500;
let tasaEmbarque = 50.5;
