const nombrePasajero = 'Leonardo';
const apellidoPasajero = 'Lacruz';

let nombreCompleto = `El nombre completo es: ${nombrePasajero} ${apellidoPasajero}`;
console.log(nombreCompleto);

let segundoPasajero = "Diego Castillo";
console.log(`El nombre del segundo Pasajero es: ${segundoPasajero}`);
segundoPasajero = 13804050;
console.log(`El nombre del segundo Pasajero es: ${segundoPasajero}`);
